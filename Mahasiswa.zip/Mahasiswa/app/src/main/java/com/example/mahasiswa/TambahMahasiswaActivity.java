package com.example.mahasiswa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class TambahMahasiswaActivity extends AppCompatActivity {

    EditText nama,nim,prodi,alamat,gambar,jenis_kelamin;
    Button btnAdd,btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_mahasiswa);

        nama = (EditText)findViewById(R.id.txtnama);
        nim = (EditText)findViewById(R.id.txtnim);
        prodi = (EditText)findViewById(R.id.txtprodi);
        alamat = (EditText)findViewById(R.id.txtalamat);
        gambar = (EditText)findViewById(R.id.txtgambar);
        jenis_kelamin = (EditText)findViewById(R.id.txtjenis);

        btnAdd =(Button)findViewById(R.id.btnAdd);
        btnBack =(Button)findViewById(R.id.btnBack);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
                clearAll();

            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void insertData()
    {

        Map<String,Object> map = new HashMap<>();
        map.put("Nama",nama.getText().toString());
        map.put("Nim",nim.getText().toString());
        map.put("Prodi",prodi.getText().toString());
        map.put("alamat",alamat.getText().toString());
        map.put("gambar",gambar.getText().toString());
        map.put("jenis_kelamin",jenis_kelamin.getText().toString());

        FirebaseDatabase.getInstance().getReference().child("data_filkom").push()
                .setValue(map)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(TambahMahasiswaActivity.this, "Tambah Data Mahasiswa Berhasil", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(TambahMahasiswaActivity.this, "Gagal Menambahkan Data Mahasiswa", Toast.LENGTH_SHORT).show();
                        
                    }
                });

    }

    private void clearAll()
    {

        nama.setText("");
        nim.setText("");
        prodi.setText("");
        alamat.setText("");
        gambar.setText("");
        jenis_kelamin.setText("");
    }
}