package com.example.mahasiswa;

public class MainModel {

    String Nama , Nim,Prodi,alamat, gambar,jenis_kelamin;

    MainModel(){

    }
    public MainModel(String nama, String nim, String prodi, String alamat, String gambar, String jenis_kelamin) {
        Nama = nama;
        Nim = nim;
        Prodi = prodi;
        this.alamat = alamat;
        this.gambar = gambar;
        this.jenis_kelamin = jenis_kelamin;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getNim() {
        return Nim;
    }

    public void setNim(String nim) {
        Nim = nim;
    }

    public String getProdi() {
        return Prodi;
    }

    public void setProdi(String prodi) {
        Prodi = prodi;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public void setJenis_kelamin(String jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }
}
